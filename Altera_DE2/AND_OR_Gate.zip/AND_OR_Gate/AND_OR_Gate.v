module AND_OR_Gate(
	input a,b,c,
	output y
);

wire x;

and (x,a,b);
or (y,x,c);

endmodule