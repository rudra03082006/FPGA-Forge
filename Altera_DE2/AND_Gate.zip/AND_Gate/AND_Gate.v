module AND_Gate(
	input a,b,
	output c
);

and(c,a,b);

endmodule
